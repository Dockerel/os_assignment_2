#include "types.h"
#include "user.h"
#include "date.h"

int main(int argc, char *argv[])
{
	struct rtcdate r;
	if(date(&r))
	{
		printf(2,"date failed\n");
		exit();
	}
	
	printf(1,"do giheon 2020114932 :\n%d-%d-%dT%d:%d:%d+09:00\n", r.year,r.month,r.day,r.hour,r.minute,r.second);
	exit();
}
